package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MyAsync extends AsyncTask<String , Void ,String > {

    private Context mContext;
    private SensorActivity sensorActivity = null ;
    public  ProgressBar progressBar;
    public boolean isDetectEmotion = false;


    public MyAsync(Context context, SensorActivity sensorActivity, ProgressBar progressBar, boolean isDetectEmotion) {
        this.isDetectEmotion = isDetectEmotion;
        this.sensorActivity=sensorActivity;
        //Relevant Context should be provided to newly created components (whether application context or activity context)
        //getApplicationContext() - Returns the context for all activities running in application
        this.progressBar = progressBar;
        mContext = context;
    }

    //Execute this before the request is made
    @Override
    protected void onPreExecute() {
        // A toast provides simple feedback about an operation as popup.
        // It takes the application Context, the text message, and the duration for the toast as arguments
        Toast.makeText(mContext, "Going for the Ping..", Toast.LENGTH_LONG).show();
        progressBar.setVisibility(View.VISIBLE);
    }

    //Perform the request in background
    @Override
    protected String doInBackground(String... params) {
       // JSONObject jsonResponse=null;

        String response = "";
        HttpURLConnection connection;
        try {
            connection = (HttpURLConnection) new URL(params[0])
                    .openConnection();

            connection.setRequestMethod("GET");
            //return connection.getResponseCode();
            InputStream responseStream = new BufferedInputStream(connection.getInputStream());
            BufferedReader responseStreamReader = new BufferedReader(new InputStreamReader(responseStream));
            String line = "";
            StringBuilder stringBuilder = new StringBuilder();
            while ((line = responseStreamReader.readLine()) != null) {
                stringBuilder.append(line);
            }
            responseStreamReader.close();

            response = stringBuilder.toString();
         //   jsonResponse = new JSONObject(response);



        connection.disconnect();

        } catch (IOException e) {
            e.printStackTrace();
        } //catch (JSONException e) {
            //e.printStackTrace();
        //}
        return response;
    }


    //Run this once the background task returns.
    @Override
    protected void onPostExecute(String jsonObject) {

        String c = jsonObject.replace(" ","");
        Toast.makeText(sensorActivity, ""+c.toString(),
                Toast.LENGTH_LONG).show();
        if(!isDetectEmotion)
        {
        c = c.replaceFirst("\"","");
        c = c.replace("\\","");
        c = replaceLast(c,"\"","");

        try {
            JSONObject object = new JSONObject(c.replace("\\","\""));
            ShowResult.BPM=object.get("BPM").toString();
            ShowResult.Emotion=object.get("result").toString();
            ShowResult.GSR=object.get("GSR").toString();
            ShowResult.Temperature=object.get("Temperature").toString();

        } catch (JSONException e) {
            e.printStackTrace();
        }

        Intent intent = new Intent(sensorActivity,ShowResult.class);
        sensorActivity.startActivity(intent);
        }

        progressBar.setVisibility(View.GONE);
    }
    public static String replaceLast(String text, String regex, String replacement) {
        return text.replaceFirst("(?s)"+regex+"(?!.*?"+regex+")", replacement);
    }

}