package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import com.mikhaellopez.circularprogressbar.CircularProgressBar;

import javax.xml.datatype.Duration;

public class SensorActivity extends AppCompatActivity {

    Button btnDet_Emotion;
    Button btnResult;

    public static String Ip = MainActivity.Ip;
    public static String port = MainActivity.port;
    ProgressBar progressBar ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor);
        getSupportActionBar().hide();



        btnDet_Emotion = findViewById(R.id.btn_detect_sensor_emo);
        btnResult = findViewById(R.id.btn_get_result);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        btnDet_Emotion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyAsync myTask = new MyAsync(getBaseContext(), SensorActivity.this , progressBar , true);
                myTask.execute("http://"+Ip+":5000/Emotion/");
            }
        });

        btnResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                MyAsync myTask = new MyAsync(getApplicationContext(),SensorActivity.this,progressBar,false);
                myTask.execute("http://"+Ip+":5000/Get_Result/");
            }
        });
       }








}
