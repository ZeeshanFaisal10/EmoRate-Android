package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Settings extends AppCompatActivity {

    EditText et1;
    EditText et2;

    String newString;
    String newString2;
    Button Apply;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        getSupportActionBar().hide();

        et1 = findViewById(R.id.my_ip);
        et2 = findViewById(R.id.my_port);
        Apply = findViewById(R.id.apply);
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if(extras == null) {
                newString= null;
                newString2= null;
            } else {
                newString= extras.getString("myip");
                newString2= extras.getString("myport");
            }
        } else {
            newString= (String) savedInstanceState.getSerializable("myip");
            newString2= (String) savedInstanceState.getSerializable("myport");
        }


        Apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                MainActivity.Ip=et1.getText().toString() ;
                MainActivity.port = et2.getText().toString();
                finish();
            }
        });

        et1.setText(newString);
        et2.setText(newString2);

    }
}
