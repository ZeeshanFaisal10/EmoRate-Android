package com.example.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;

public class MainActivity extends AppCompatActivity {
    public static int count = 0;
    public Fragment fragment;
    Button btnEmotion;
    Button btnEmotionBack;
    Button btnSensor;
    int TAKE_PHOTO_CODE = 0;
    public static String Ip = "35.229.32.60";
 //   public static String Ip = "192.168.43.128";
    public static String port = "5001";
    Button btnSet;
    String img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        btnSet = findViewById(R.id.btn_sett);
        btnSensor = findViewById(R.id.btn_detect_sensor);

        Fragment fragment_homepage = new fragment_homepage();
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.fragment_facial_emotion, fragment_homepage);
        ft.commit();
        final String dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/picFolder/";
        File newdir = new File(dir);
        newdir.mkdirs();

        btnEmotion = findViewById(R.id.btn_detect_emotion);
        btnEmotionBack = findViewById(R.id.btn_detect_emotion_again);
        btnEmotion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getBaseContext(),"Ip:"+Ip+", Port:"+port,Toast.LENGTH_LONG).show();
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); //IMAGE CAPTURE CODE
                startActivityForResult(intent, 0);


            }
        });


        btnSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getBaseContext(),"aa",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(MainActivity.this, Settings.class);
                intent.putExtra("myip", Ip);
                intent.putExtra("myport", port);
                startActivity(intent);

            }
        });

        btnEmotionBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment_homepage fragment = new fragment_homepage();
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.fragment_facial_emotion, fragment);
                ft.commit();
                btnEmotionBack.setVisibility(View.GONE);
                btnEmotion.setVisibility(View.VISIBLE);

            }
        });

        ///Sensor button click
        btnSensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ss = new Intent(MainActivity.this,SensorActivity.class);
                startActivity(ss);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            img = Base64.encodeToString(byteArray, Base64.DEFAULT);
            AsyncEmotionDetection_API api = new AsyncEmotionDetection_API(getBaseContext(), getSupportFragmentManager());

            JSONObject jsonObject = null;
            api.execute("http://"+Ip + ":" + port + "/Img_Emotion/", img);
        } catch (Exception ex) {
            Toast.makeText(getBaseContext(), img, Toast.LENGTH_LONG);
        }

        btnEmotionBack.setVisibility(View.VISIBLE);
        btnEmotion.setVisibility(View.GONE);
        Toast.makeText(getBaseContext(), img, Toast.LENGTH_LONG);
    }

}
