package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.text.DecimalFormat;

public class ShowResult extends AppCompatActivity {

    public static String GSR = null;
    public static String BPM = null;
    public static String Temperature = null;
    public static String Emotion = null;
    TextView txtEmotion =null;
    TextView txtBPM =null;
    TextView txtTemperature =null;
    TextView txtGSR =null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_result);
        getSupportActionBar().hide();
        txtEmotion =     (TextView) findViewById(R.id.txtEmotion);
        txtGSR =         (TextView) findViewById(R.id.txt_gsr);
        txtBPM =         (TextView) findViewById(R.id.txt_pulse);
        txtTemperature = (TextView) findViewById(R.id.txt_temp);

        txtGSR.setText(""+(int)Double.parseDouble(GSR));
        txtBPM.setText(""+(int)Double.parseDouble(BPM));
        txtTemperature.setText(new DecimalFormat("##.##").format(Double.parseDouble(Temperature)));
        txtEmotion.setText(Emotion);



    }


}
